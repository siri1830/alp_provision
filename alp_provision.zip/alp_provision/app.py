#!/usr/bin/env python

from flask import Flask, session, render_template, request, jsonify, redirect, url_for, make_response, Response
from flask_sso import SSO
import uuid
from random import randint
from datetime import date
import datetime
import time
import requests
import urllib3
import json
from requests.auth import HTTPBasicAuth
import os
import logging
import base64
from utils.db_utils import fetch_user_account_type


requests.packages.urllib3.disable_warnings()
application = Flask(__name__)
application.secret_key = os.urandom(24)

heat_base_url = 'heat.hban.us'
heat_api_url = 'http://heat-restapi-prod-heat-svc:8080/api'

session = {"id":"qwer"}

def checklogin_status():
    # print str(time.time())
    # print str(session.get('login_expire'))
    # print (time.time() >= session.get('login_expire'))
    if session.get('id') is None:
        return redirect("https://www.huntington.com")
    if time.time() >= session.get('login_expire'):
    #    print "testing **********"
       redirect("http://www.huntington.com")
       return redirect('https://heat-lab.hban.us')



@application.route('/')
def home():
    id = request.headers.get('remote_user')
    # print id
    session['id'] = id
    # logger_obj.info("Logged In user " + str(id))
    return render_template('index.html', username = session['id'])


@application.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('home'))
    return render_template('login.html', error=error)

@application.route('/logout')
def logout():
    del session['id']
    return redirect('http://www.huntington.com')

@application.route('/check_and_upgrade', methods=['POST', 'GET'])
def check_and_upgrade():
    if request.method == 'POST':
        result = request.form
        user_id = result['user_id']
        plan = fetch_user_account_type(user_id)
        error_msg = "Error while fetching users details, please check the entered user details"
        if plan is not None:
            if plan == "stakeholder":
                url = "post_url"
                headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
                response = requests.post(url, data={}, headers=headers,
                                         auth=HTTPBasicAuth('srvheatapipd', 'li6W12b8'))
                if response.status_code == 200 :
                    return render_template('alp_provision.html', username=session['id'], message="Successfully Upgraded", msg_color="lightgreen")
            else:
                error_msg = "User accountlicensetype is not stakeholder, so it not upgrade "
        return render_template('alp_provision.html', username = session['id'], message=error_msg, msg_color="red")


@application.route('/alp', methods=['POST', 'GET'])
def alp():
    return render_template('alp_provision.html', username = session['id'], message='')


if __name__ == '__main__':
    application.run(host="0.0.0.0", port=8080, debug=True)

