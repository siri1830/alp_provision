# Frontend
This is the code repository for the HEAT front end

## What is this repository about?
It's the code that makes HEAT tick

## Changelog
See CHANGELOG.md for more information

## Contributing
For bugs, feature requests and more, contact eca@huntington.com.