import psycopg2
from datetime import datetime
import pandas as pd

def fetch_user_account_type(user_id):
    conn = psycopg2.connect(
        database="postgres", user='postgres', password='123456', host='127.0.0.1', port='5432')

    df = pd.read_sql(f"SELECT * FROM public.alp_license where user_id = '{user_id}'", conn)
    if df.empty:
        return None
    return list(df['accountlicensetype'])[0]
