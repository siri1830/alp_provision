function templateSelect() {
  switch(document.getElementById('ServerTemplateType').value){
    case "default":
      $('#ostypeselect option[value!=""]').show();
      $('#ostypeselect').val("");
      $('#ostypeselect').trigger('change');
      $('#puppetrole').val("base");
      $('#puppetprofile').val("base");
      $('#addomain').val("");
      $('#applicationtext').val("");
      $('#functiontext').val("");
      $('#domainselect').val("");
      $('#cmdbenvselect').val("");
      $('#hardwareselect').val("");
      $('#servernametext').val("");
      $('#fqdntext').val("");
      $('#hardwareselect').trigger('change');
      $('#Vcenterlocation').val("");
      $('#Vcenterlocation').trigger('change');
      $('#Vcenterlocation').val("");
      $('#Vcenterlocation').trigger('change');
      $('#vcenterselect').val("");
      $('#vcenterselect').trigger('change');
      $('#datacenterselect').val("");
      $('#datacenterselect').trigger('change');
      $('#clusterselect').val("");
      $('#clusterselect').trigger('change');
      $('#datastoreselect').val("");
      $('#datastoreselect').trigger('change');
      $('#networkselect').val("");
      $('#networkselect').trigger('change');
      $('#subnetselect').val("");
      $('#subnetselect').trigger('change');
      $('#uniquestringtext').val("");
      generate();
      break;
    case "windc":
      $('#ostypeselect option[value!="w"]').hide();
      $('#ostypeselect').val("w");
      $('#ostypeselect').trigger('change');
      $('#puppetrole').val("activedirectory");
      $('#puppetprofile').val("domaincontroller");
      $('#addomain').val("hbanc.hban.us");
      $('#applicationtext').val("ads");
      $('#functiontext').val("ent");
      $('#domainselect').val("hban.us");
      $('#cmdbenvselect').val("pd");
      $('#hardwareselect').val("2CPU x 8GB x 90GB");
      $('#hardwareselect').trigger('change');
      generate();
      break;
  }
}
